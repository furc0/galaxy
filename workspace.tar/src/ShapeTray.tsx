import React from 'react';
import { motion } from 'framer-motion';
import { Shape, Theme } from './types';
import { getShapeBounds } from './shapes';

interface ShapeTrayProps {
  shapes: (Shape | null)[];
  theme: Theme;
  selectedIndex: number | null;
  onSelect: (index: number) => void;
}

const ShapePiece: React.FC<{ shape: Shape; theme: Theme; isSelected: boolean; onClick: () => void }> = ({ shape, theme, isSelected, onClick }) => {
  const bounds = getShapeBounds(shape.cells);
  const rows = bounds.maxRow - bounds.minRow + 1;
  const cols = bounds.maxCol - bounds.minCol + 1;
  const cellSize = Math.min(28, 80 / Math.max(rows, cols));

  return (
    <motion.button
      className="relative flex items-center justify-center rounded-xl p-2 min-w-[70px] min-h-[70px]"
      onClick={onClick}
      whileTap={{ scale: 0.9 }}
      animate={{
        scale: isSelected ? 1.05 : 1,
        boxShadow: isSelected
          ? `0 0 20px ${shape.color}60`
          : `0 0 0px transparent`,
      }}
      transition={{ type: 'spring', stiffness: 400, damping: 25 }}
      style={{
        background: isSelected ? `${shape.color}15` : 'rgba(255,255,255,0.03)',
        border: `1px solid ${isSelected ? shape.color + '60' : theme.cellBorder}`,
      }}
    >
      <div
        className="grid gap-[2px]"
        style={{
          gridTemplateColumns: `repeat(${cols}, ${cellSize}px)`,
          gridTemplateRows: `repeat(${rows}, ${cellSize}px)`,
        }}
      >
        {Array.from({ length: rows * cols }).map((_, idx) => {
          const r = Math.floor(idx / cols);
          const c = idx % cols;
          const hasCell = shape.cells.some(
            cell => cell.row - bounds.minRow === r && cell.col - bounds.minCol === c
          );

          return (
            <div
              key={idx}
              className="rounded-[3px]"
              style={{
                width: cellSize,
                height: cellSize,
                background: hasCell ? shape.color : 'transparent',
                boxShadow: hasCell
                  ? `0 0 6px ${shape.color}40, inset 0 1px 2px rgba(255,255,255,0.2)`
                  : 'none',
              }}
            />
          );
        })}
      </div>
    </motion.button>
  );
};

export const ShapeTray: React.FC<ShapeTrayProps> = React.memo(({ shapes, theme, selectedIndex, onSelect }) => {
  return (
    <div className="flex items-center justify-center gap-3 py-3">
      {shapes.map((shape, index) => (
        <motion.div
          key={shape?.id || `empty-${index}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1, type: 'spring', stiffness: 300 }}
        >
          {shape ? (
            <ShapePiece
              shape={shape}
              theme={theme}
              isSelected={selectedIndex === index}
              onClick={() => onSelect(index)}
            />
          ) : (
            <div className="min-w-[70px] min-h-[70px] rounded-xl opacity-20"
              style={{ background: 'rgba(255,255,255,0.03)', border: `1px solid ${theme.cellBorder}` }}
            />
          )}
        </motion.div>
      ))}
    </div>
  );
});

ShapeTray.displayName = 'ShapeTray';
