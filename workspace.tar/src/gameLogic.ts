import { CellState, GameState, Position, Shape } from './types';
import { generateShapes } from './shapes';

const GRID_SIZE = 8;

export function createEmptyGrid(size: number = GRID_SIZE): CellState[][] {
  return Array.from({ length: size }, () => Array(size).fill('empty'));
}

export function createEmptyColorGrid(size: number = GRID_SIZE): (string | null)[][] {
  return Array.from({ length: size }, () => Array(size).fill(null));
}

export function canPlaceShape(
  grid: CellState[][],
  shape: Shape,
  position: Position
): boolean {
  for (const cell of shape.cells) {
    const row = position.row + cell.row;
    const col = position.col + cell.col;
    if (row < 0 || row >= grid.length || col < 0 || col >= grid[0].length) {
      return false;
    }
    if (grid[row][col] !== 'empty') {
      return false;
    }
  }
  return true;
}

export function placeShape(
  grid: CellState[][],
  colorGrid: (string | null)[][],
  shape: Shape,
  position: Position
): { newGrid: CellState[][]; newColorGrid: (string | null)[][] } {
  const newGrid = grid.map(row => [...row]);
  const newColorGrid = colorGrid.map(row => [...row]);

  for (const cell of shape.cells) {
    const row = position.row + cell.row;
    const col = position.col + cell.col;
    newGrid[row][col] = 'filled';
    newColorGrid[row][col] = shape.color;
  }

  return { newGrid, newColorGrid };
}

export function findCompletedLines(grid: CellState[][]): { rows: number[]; cols: number[] } {
  const size = grid.length;
  const completedRows: number[] = [];
  const completedCols: number[] = [];

  // Check rows
  for (let r = 0; r < size; r++) {
    if (grid[r].every(cell => cell === 'filled')) {
      completedRows.push(r);
    }
  }

  // Check columns
  for (let c = 0; c < size; c++) {
    let complete = true;
    for (let r = 0; r < size; r++) {
      if (grid[r][c] !== 'filled') {
        complete = false;
        break;
      }
    }
    if (complete) {
      completedCols.push(c);
    }
  }

  return { rows: completedRows, cols: completedCols };
}

export function clearLines(
  grid: CellState[][],
  colorGrid: (string | null)[][],
  rows: number[],
  cols: number[]
): { newGrid: CellState[][]; newColorGrid: (string | null)[][]; cellsCleared: Position[] } {
  const newGrid = grid.map(row => [...row]);
  const newColorGrid = colorGrid.map(row => [...row]);
  const cellsCleared: Position[] = [];

  for (const r of rows) {
    for (let c = 0; c < grid[0].length; c++) {
      newGrid[r][c] = 'empty';
      newColorGrid[r][c] = null;
      cellsCleared.push({ row: r, col: c });
    }
  }

  for (const c of cols) {
    for (let r = 0; r < grid.length; r++) {
      newGrid[r][c] = 'empty';
      newColorGrid[r][c] = null;
      cellsCleared.push({ row: r, col: c });
    }
  }

  return { newGrid, newColorGrid, cellsCleared };
}

export function calculateScore(linesCleared: number, combo: number): number {
  const baseScore = linesCleared * 100;
  const comboMultiplier = 1 + (combo * 0.5);
  const lineBonus = linesCleared > 1 ? linesCleared * 50 : 0;
  return Math.floor((baseScore + lineBonus) * comboMultiplier);
}

export function canAnyShapeBePlaced(grid: CellState[][], shapes: (Shape | null)[]): boolean {
  const size = grid.length;
  for (const shape of shapes) {
    if (!shape) continue;
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (canPlaceShape(grid, shape, { row: r, col: c })) {
          return true;
        }
      }
    }
  }
  return false;
}

export function createInitialState(colors: string[], mode: 'free' | 'level' = 'free', level: number | null = null): GameState {
  const difficulty = level || 1;
  return {
    grid: createEmptyGrid(),
    gridColors: createEmptyColorGrid(),
    score: 0,
    highScore: parseInt(localStorage.getItem('prism_highscore') || '0'),
    combo: 0,
    maxCombo: 0,
    shapes: generateShapes(3, colors, difficulty),
    isGameOver: false,
    linesCleared: 0,
    totalLinesCleared: 0,
    level,
    mode,
  };
}

export function getDifficultyForLevel(level: number): number {
  return Math.min(Math.floor(level / 2) + 1, 10);
}
