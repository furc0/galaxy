import React from 'react';
import { motion } from 'framer-motion';
import { Theme } from './types';

interface MenuScreenProps {
  theme: Theme;
  highScore: number;
  onFreeGame: () => void;
  onLevels: () => void;
  onSettings: () => void;
}

export const MenuScreen: React.FC<MenuScreenProps> = ({ theme, highScore, onFreeGame, onLevels, onSettings }) => {
  return (
    <motion.div
      className="flex flex-col items-center justify-center h-full px-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Logo */}
      <motion.div
        className="mb-8"
        initial={{ y: -30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
      >
        <h1
          className="text-5xl font-light tracking-widest"
          style={{ color: theme.textPrimary }}
        >
          PRISM
        </h1>
        <motion.div
          className="h-[2px] mt-2 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: '100%' }}
          transition={{ delay: 0.5, duration: 0.8 }}
          style={{ background: `linear-gradient(90deg, transparent, ${theme.accent}, transparent)` }}
        />
        <p className="text-center mt-3 text-sm tracking-wider" style={{ color: theme.textSecondary }}>
          find your flow
        </p>
      </motion.div>

      {/* High Score */}
      {highScore > 0 && (
        <motion.div
          className="mb-8 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <p className="text-xs uppercase tracking-wider" style={{ color: theme.textSecondary }}>Best Score</p>
          <p className="text-2xl font-light" style={{ color: theme.accent }}>{highScore.toLocaleString()}</p>
        </motion.div>
      )}

      {/* Buttons */}
      <div className="flex flex-col gap-4 w-full max-w-[280px]">
        <motion.button
          className="py-4 px-8 rounded-2xl text-lg font-medium tracking-wide"
          onClick={onFreeGame}
          whileTap={{ scale: 0.95 }}
          initial={{ x: -30, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.4, type: 'spring', stiffness: 200 }}
          style={{
            background: `linear-gradient(135deg, ${theme.accent}30, ${theme.accent}10)`,
            border: `1px solid ${theme.accent}40`,
            color: theme.textPrimary,
            boxShadow: `0 4px 20px ${theme.accent}20`,
          }}
        >
          Free Play
        </motion.button>

        <motion.button
          className="py-4 px-8 rounded-2xl text-lg font-medium tracking-wide"
          onClick={onLevels}
          whileTap={{ scale: 0.95 }}
          initial={{ x: 30, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.5, type: 'spring', stiffness: 200 }}
          style={{
            background: 'rgba(255,255,255,0.03)',
            border: `1px solid ${theme.cellBorder}`,
            color: theme.textPrimary,
          }}
        >
          Levels
        </motion.button>

        <motion.button
          className="py-3 px-8 rounded-2xl text-sm tracking-wide"
          onClick={onSettings}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          style={{
            background: 'transparent',
            border: `1px solid ${theme.cellBorder}`,
            color: theme.textSecondary,
          }}
        >
          Settings
        </motion.button>
      </div>

      {/* Floating orbs decoration */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: 100 + i * 40,
              height: 100 + i * 40,
              background: `radial-gradient(circle, ${theme.colors[i % theme.colors.length]}15, transparent)`,
              left: `${10 + i * 20}%`,
              top: `${20 + (i % 3) * 25}%`,
            }}
            animate={{
              x: [0, 20, -10, 0],
              y: [0, -15, 10, 0],
              scale: [1, 1.1, 0.95, 1],
            }}
            transition={{
              duration: 8 + i * 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>
    </motion.div>
  );
};
