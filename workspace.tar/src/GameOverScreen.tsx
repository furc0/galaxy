import React from 'react';
import { motion } from 'framer-motion';
import { Theme, GameState } from './types';

interface GameOverScreenProps {
  theme: Theme;
  gameState: GameState;
  onRestart: () => void;
  onMenu: () => void;
}

export const GameOverScreen: React.FC<GameOverScreenProps> = ({ theme, gameState, onRestart, onMenu }) => {
  const isNewHighScore = gameState.score >= gameState.highScore && gameState.score > 0;

  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center z-50 px-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(10px)' }}
    >
      <motion.div
        className="text-center"
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, type: 'spring', stiffness: 200 }}
      >
        {isNewHighScore && (
          <motion.p
            className="text-sm uppercase tracking-widest mb-2"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            style={{ color: theme.accent }}
          >
            ✨ New Best! ✨
          </motion.p>
        )}

        <h2
          className="text-4xl font-light tracking-wider mb-6"
          style={{ color: theme.textPrimary }}
        >
          Game Over
        </h2>

        <div className="space-y-4 mb-8">
          <div>
            <p className="text-xs uppercase tracking-wider" style={{ color: theme.textSecondary }}>Score</p>
            <motion.p
              className="text-3xl font-light"
              style={{ color: theme.textPrimary }}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.6, type: 'spring', stiffness: 300 }}
            >
              {gameState.score.toLocaleString()}
            </motion.p>
          </div>

          <div className="flex gap-8 justify-center">
            <div>
              <p className="text-xs uppercase tracking-wider" style={{ color: theme.textSecondary }}>Lines</p>
              <p className="text-xl font-light" style={{ color: theme.textPrimary }}>
                {gameState.totalLinesCleared}
              </p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider" style={{ color: theme.textSecondary }}>Max Combo</p>
              <p className="text-xl font-light" style={{ color: theme.accent }}>
                x{gameState.maxCombo}
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-3 w-full max-w-[240px] mx-auto">
          <motion.button
            className="py-3 px-8 rounded-2xl text-base font-medium tracking-wide"
            onClick={onRestart}
            whileTap={{ scale: 0.95 }}
            style={{
              background: `linear-gradient(135deg, ${theme.accent}30, ${theme.accent}10)`,
              border: `1px solid ${theme.accent}40`,
              color: theme.textPrimary,
            }}
          >
            Play Again
          </motion.button>
          <motion.button
            className="py-3 px-8 rounded-2xl text-sm tracking-wide"
            onClick={onMenu}
            whileTap={{ scale: 0.95 }}
            style={{
              background: 'transparent',
              border: `1px solid ${theme.cellBorder}`,
              color: theme.textSecondary,
            }}
          >
            Menu
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
};
