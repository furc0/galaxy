import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { CellState, Position, Shape, Theme } from './types';
import { canPlaceShape } from './gameLogic';

interface GridProps {
  grid: CellState[][];
  gridColors: (string | null)[][];
  theme: Theme;
  clearedCells: Position[];
  dragShape: Shape | null;
  dragPosition: Position | null;
  onCellClick?: (pos: Position) => void;
}

const GRID_SIZE = 8;

export const Grid: React.FC<GridProps> = React.memo(({
  grid,
  gridColors,
  theme,
  clearedCells,
  dragShape,
  dragPosition,
}) => {
  const clearedSet = useMemo(() => {
    const set = new Set<string>();
    clearedCells.forEach(c => set.add(`${c.row}-${c.col}`));
    return set;
  }, [clearedCells]);

  const previewCells = useMemo(() => {
    if (!dragShape || !dragPosition) return new Set<string>();
    const set = new Set<string>();
    const valid = canPlaceShape(grid, dragShape, dragPosition);
    if (valid) {
      dragShape.cells.forEach(cell => {
        const r = dragPosition.row + cell.row;
        const c = dragPosition.col + cell.col;
        set.add(`${r}-${c}`);
      });
    }
    return set;
  }, [dragShape, dragPosition, grid]);

  return (
    <div
      className="relative rounded-2xl p-1"
      style={{
        background: theme.gridBg,
        boxShadow: `0 0 40px ${theme.glowColor}, inset 0 0 20px rgba(0,0,0,0.3)`,
      }}
    >
      <div
        className="grid gap-[2px] rounded-xl overflow-hidden"
        style={{
          gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)`,
          aspectRatio: '1',
        }}
      >
        {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, idx) => {
          const row = Math.floor(idx / GRID_SIZE);
          const col = idx % GRID_SIZE;
          const cellState = grid[row][col];
          const cellColor = gridColors[row][col];
          const key = `${row}-${col}`;
          const isCleared = clearedSet.has(key);
          const isPreview = previewCells.has(key);

          return (
            <motion.div
              key={key}
              className="relative rounded-sm"
              initial={false}
              animate={
                isCleared
                  ? { scale: [1, 1.3, 0], opacity: [1, 1, 0] }
                  : cellState === 'filled'
                  ? { scale: 1, opacity: 1 }
                  : { scale: 1, opacity: 1 }
              }
              transition={
                isCleared
                  ? { duration: 0.4, ease: 'easeOut' }
                  : { duration: 0.15 }
              }
              style={{
                background: isPreview
                  ? `${dragShape?.color}40`
                  : cellState === 'filled' && cellColor
                  ? cellColor
                  : theme.cellEmpty,
                border: `1px solid ${theme.cellBorder}`,
                boxShadow: cellState === 'filled' && cellColor
                  ? `0 0 8px ${cellColor}60, inset 0 1px 2px rgba(255,255,255,0.2)`
                  : 'none',
              }}
            >
              {cellState === 'filled' && cellColor && !isCleared && (
                <motion.div
                  className="absolute inset-0 rounded-sm"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                  style={{
                    background: `linear-gradient(135deg, ${cellColor} 0%, ${cellColor}cc 100%)`,
                    boxShadow: `inset 0 1px 3px rgba(255,255,255,0.3)`,
                  }}
                />
              )}
              {isPreview && (
                <motion.div
                  className="absolute inset-0 rounded-sm"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 1, repeat: Infinity }}
                  style={{
                    background: `${dragShape?.color}30`,
                    border: `1px solid ${dragShape?.color}60`,
                  }}
                />
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
});

Grid.displayName = 'Grid';
