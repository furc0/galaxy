import React, { useState, useCallback, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { GameScreen } from './GameScreen';
import { MenuScreen } from './MenuScreen';
import { LevelsScreen } from './LevelsScreen';
import { SettingsScreen } from './SettingsScreen';
import { useGame } from './useGame';
import { themes } from './themes';


type Screen = 'menu' | 'game' | 'levels' | 'settings';

function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [themeIndex, setThemeIndex] = useState(() => {
    const saved = localStorage.getItem('prism_theme_index');
    return saved ? parseInt(saved) : 0;
  });

  const {
    gameState,
    currentTheme,
    clearedCells,
    showCombo,
    lastScore,
    startFreeGame,
    startLevel,
    placeShapeAt,
    resetGame,
  } = useGame();

  // Use dynamic theme based on game state or manual selection
  const activeTheme = screen === 'game' && gameState ? currentTheme : themes[themeIndex];

  // Save theme preference
  useEffect(() => {
    localStorage.setItem('prism_theme_index', themeIndex.toString());
  }, [themeIndex]);

  const handleFreeGame = useCallback(() => {
    startFreeGame();
    setScreen('game');
  }, [startFreeGame]);

  const handleSelectLevel = useCallback((levelId: number) => {
    startLevel(levelId);
    setScreen('game');
  }, [startLevel]);

  const handleRestart = useCallback(() => {
    if (gameState?.mode === 'level' && gameState.level) {
      startLevel(gameState.level);
    } else {
      startFreeGame();
    }
  }, [gameState, startLevel, startFreeGame]);

  const handleMenu = useCallback(() => {
    resetGame();
    setScreen('menu');
  }, [resetGame]);

  const handleResetProgress = useCallback(() => {
    localStorage.removeItem('prism_highscore');
    localStorage.removeItem('prism_unlocked_levels');
    for (let i = 1; i <= 12; i++) {
      localStorage.removeItem(`prism_level_${i}_stars`);
    }
  }, []);

  return (
    <div
      className="w-full h-full overflow-hidden relative transition-all duration-1000"
      style={{ background: activeTheme.bgGradient }}
    >
      {/* Ambient background animation */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute w-[200%] h-[200%] -left-1/2 -top-1/2"
          animate={{
            rotate: [0, 360],
          }}
          transition={{
            duration: 120,
            repeat: Infinity,
            ease: 'linear',
          }}
          style={{
            background: `radial-gradient(ellipse at 30% 50%, ${activeTheme.accent}08 0%, transparent 50%),
                         radial-gradient(ellipse at 70% 50%, ${activeTheme.colors[1]}06 0%, transparent 50%)`,
          }}
        />
      </div>

      {/* Screen content */}
      <div className="relative z-10 h-full">
        <AnimatePresence mode="wait">
          {screen === 'menu' && (
            <MenuScreen
              key="menu"
              theme={activeTheme}
              highScore={parseInt(localStorage.getItem('prism_highscore') || '0')}
              onFreeGame={handleFreeGame}
              onLevels={() => setScreen('levels')}
              onSettings={() => setScreen('settings')}
            />
          )}

          {screen === 'game' && gameState && (
            <GameScreen
              key="game"
              gameState={gameState}
              theme={activeTheme}
              clearedCells={clearedCells}
              showCombo={showCombo}
              lastScore={lastScore}
              onPlaceShape={placeShapeAt}
              onRestart={handleRestart}
              onMenu={handleMenu}
            />
          )}

          {screen === 'levels' && (
            <LevelsScreen
              key="levels"
              theme={activeTheme}
              onSelectLevel={handleSelectLevel}
              onBack={() => setScreen('menu')}
            />
          )}

          {screen === 'settings' && (
            <SettingsScreen
              key="settings"
              theme={activeTheme}
              currentThemeIndex={themeIndex}
              onThemeChange={setThemeIndex}
              onBack={() => setScreen('menu')}
              onResetProgress={handleResetProgress}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default App;
