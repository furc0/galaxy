import { Level } from './types';

export const levels: Level[] = [
  { id: 1, name: 'First Light', gridSize: 8, targetScore: 300, linesToClear: 2, shapesPerRound: 3, description: 'Place shapes to fill lines' },
  { id: 2, name: 'Rising Tide', gridSize: 8, targetScore: 600, linesToClear: 4, shapesPerRound: 3, description: 'Clear 4 lines to advance' },
  { id: 3, name: 'Cascade', gridSize: 8, targetScore: 1000, linesToClear: 6, shapesPerRound: 3, description: 'Bigger shapes appear' },
  { id: 4, name: 'Momentum', gridSize: 8, targetScore: 1500, linesToClear: 8, shapesPerRound: 3, description: 'Keep the chain going' },
  { id: 5, name: 'Flow State', gridSize: 8, targetScore: 2000, linesToClear: 10, shapesPerRound: 3, description: 'Find your rhythm' },
  { id: 6, name: 'Deep Focus', gridSize: 8, targetScore: 2800, linesToClear: 12, shapesPerRound: 3, description: 'Complex shapes unlock' },
  { id: 7, name: 'Zenith', gridSize: 8, targetScore: 3500, linesToClear: 14, shapesPerRound: 3, description: 'Master the grid' },
  { id: 8, name: 'Transcend', gridSize: 8, targetScore: 4500, linesToClear: 16, shapesPerRound: 3, description: 'Push your limits' },
  { id: 9, name: 'Infinity', gridSize: 8, targetScore: 6000, linesToClear: 20, shapesPerRound: 3, description: 'Near-perfect play required' },
  { id: 10, name: 'Eternity', gridSize: 8, targetScore: 8000, linesToClear: 25, shapesPerRound: 3, description: 'The ultimate challenge' },
  { id: 11, name: 'Beyond', gridSize: 8, targetScore: 10000, linesToClear: 30, shapesPerRound: 3, description: 'True mastery' },
  { id: 12, name: 'Singularity', gridSize: 8, targetScore: 15000, linesToClear: 40, shapesPerRound: 3, description: 'Legend status' },
];

export function getLevelById(id: number): Level | undefined {
  return levels.find(l => l.id === id);
}

export function getUnlockedLevels(): number {
  const unlocked = localStorage.getItem('prism_unlocked_levels');
  return unlocked ? parseInt(unlocked) : 1;
}

export function unlockLevel(id: number): void {
  const current = getUnlockedLevels();
  if (id > current) {
    localStorage.setItem('prism_unlocked_levels', id.toString());
  }
}

export function getLevelStars(id: number): number {
  const stars = localStorage.getItem(`prism_level_${id}_stars`);
  return stars ? parseInt(stars) : 0;
}

export function setLevelStars(id: number, stars: number): void {
  const current = getLevelStars(id);
  if (stars > current) {
    localStorage.setItem(`prism_level_${id}_stars`, stars.toString());
  }
}

export function calculateStars(score: number, targetScore: number): number {
  if (score >= targetScore * 2) return 3;
  if (score >= targetScore * 1.5) return 2;
  if (score >= targetScore) return 1;
  return 0;
}
