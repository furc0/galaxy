import React from 'react';
import { motion } from 'framer-motion';
import { Theme } from './types';
import { themes } from './themes';

interface SettingsScreenProps {
  theme: Theme;
  currentThemeIndex: number;
  onThemeChange: (index: number) => void;
  onBack: () => void;
  onResetProgress: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  theme,
  currentThemeIndex,
  onThemeChange,
  onBack,
  onResetProgress,
}) => {
  return (
    <motion.div
      className="flex flex-col h-full px-6 py-8"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3 }}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <motion.button
          onClick={onBack}
          whileTap={{ scale: 0.9 }}
          className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{
            background: 'rgba(255,255,255,0.05)',
            border: `1px solid ${theme.cellBorder}`,
            color: theme.textPrimary,
          }}
        >
          ←
        </motion.button>
        <h2 className="text-xl font-light tracking-wider" style={{ color: theme.textPrimary }}>
          Settings
        </h2>
        <div className="w-10" />
      </div>

      {/* Theme Selection */}
      <div className="mb-8">
        <p className="text-sm uppercase tracking-wider mb-4" style={{ color: theme.textSecondary }}>
          Theme
        </p>
        <div className="flex gap-3 flex-wrap">
          {themes.map((t, index) => (
            <motion.button
              key={t.id}
              className="w-14 h-14 rounded-xl flex items-center justify-center relative overflow-hidden"
              onClick={() => onThemeChange(index)}
              whileTap={{ scale: 0.9 }}
              style={{
                background: t.bgGradient,
                border: `2px solid ${index === currentThemeIndex ? t.accent : 'transparent'}`,
                boxShadow: index === currentThemeIndex ? `0 0 12px ${t.accent}40` : 'none',
              }}
            >
              <div
                className="w-4 h-4 rounded-full"
                style={{ background: t.accent, boxShadow: `0 0 8px ${t.accent}` }}
              />
              <span className="absolute bottom-1 text-[8px]" style={{ color: t.textSecondary }}>
                {t.name}
              </span>
            </motion.button>
          ))}
        </div>
        <p className="text-xs mt-3" style={{ color: theme.textSecondary }}>
          Theme changes as you play, or pick your favorite
        </p>
      </div>

      {/* Stats */}
      <div className="mb-8">
        <p className="text-sm uppercase tracking-wider mb-4" style={{ color: theme.textSecondary }}>
          Stats
        </p>
        <div className="space-y-3">
          <div className="flex justify-between items-center py-2" style={{ borderBottom: `1px solid ${theme.cellBorder}` }}>
            <span className="text-sm" style={{ color: theme.textSecondary }}>High Score</span>
            <span className="text-sm font-light" style={{ color: theme.textPrimary }}>
              {parseInt(localStorage.getItem('prism_highscore') || '0').toLocaleString()}
            </span>
          </div>
          <div className="flex justify-between items-center py-2" style={{ borderBottom: `1px solid ${theme.cellBorder}` }}>
            <span className="text-sm" style={{ color: theme.textSecondary }}>Levels Unlocked</span>
            <span className="text-sm font-light" style={{ color: theme.textPrimary }}>
              {localStorage.getItem('prism_unlocked_levels') || '1'} / 12
            </span>
          </div>
        </div>
      </div>

      {/* Reset */}
      <div className="mt-auto">
        <motion.button
          className="w-full py-3 rounded-xl text-sm"
          onClick={onResetProgress}
          whileTap={{ scale: 0.95 }}
          style={{
            background: 'rgba(255,50,50,0.05)',
            border: '1px solid rgba(255,50,50,0.2)',
            color: 'rgba(255,100,100,0.7)',
          }}
        >
          Reset Progress
        </motion.button>
      </div>
    </motion.div>
  );
};
