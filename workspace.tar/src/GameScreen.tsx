import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GameState, Position, Shape, Theme } from './types';
import { Grid } from './Grid';
import { ShapeTray } from './ShapeTray';
import { ParticleEffect } from './ParticleEffect';
import { GameOverScreen } from './GameOverScreen';
import { getShapeBounds } from './shapes';

interface GameScreenProps {
  gameState: GameState;
  theme: Theme;
  clearedCells: Position[];
  showCombo: boolean;
  lastScore: number;
  onPlaceShape: (shapeIndex: number, position: Position) => boolean;
  onRestart: () => void;
  onMenu: () => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  gameState,
  theme,
  clearedCells,
  showCombo,
  lastScore,
  onPlaceShape,
  onRestart,
  onMenu,
}) => {
  const [selectedShape, setSelectedShape] = useState<number | null>(null);
  const [dragPosition, setDragPosition] = useState<Position | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const gridRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const gridSize = 8;

  const getGridPosition = useCallback((clientX: number, clientY: number): Position | null => {
    if (!gridRef.current) return null;
    const rect = gridRef.current.getBoundingClientRect();
    const cellWidth = rect.width / gridSize;
    const cellHeight = rect.height / gridSize;

    const col = Math.floor((clientX - rect.left) / cellWidth);
    const row = Math.floor((clientY - rect.top) / cellHeight);

    if (row < 0 || row >= gridSize || col < 0 || col >= gridSize) return null;
    return { row, col };
  }, [gridSize]);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (selectedShape === null) return;
    const touch = e.touches[0];
    const pos = getGridPosition(touch.clientX, touch.clientY - 60);
    if (pos) {
      setDragPosition(pos);
      setIsDragging(true);
    }
  }, [selectedShape, getGridPosition]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDragging || selectedShape === null) return;
    e.preventDefault();
    const touch = e.touches[0];
    const pos = getGridPosition(touch.clientX, touch.clientY - 60);
    setDragPosition(pos);
  }, [isDragging, selectedShape, getGridPosition]);

  const handleTouchEnd = useCallback(() => {
    if (!isDragging || selectedShape === null || !dragPosition) {
      setIsDragging(false);
      return;
    }

    const shape = gameState.shapes[selectedShape];
    if (shape) {
      // Adjust position so shape is centered on touch point
      const bounds = getShapeBounds(shape.cells);
      const adjustedPos: Position = {
        row: dragPosition.row - Math.floor((bounds.maxRow - bounds.minRow) / 2),
        col: dragPosition.col - Math.floor((bounds.maxCol - bounds.minCol) / 2),
      };

      const placed = onPlaceShape(selectedShape, adjustedPos);
      if (placed) {
        setSelectedShape(null);
      }
    }

    setIsDragging(false);
    setDragPosition(null);
  }, [isDragging, selectedShape, dragPosition, gameState.shapes, onPlaceShape]);

  // Mouse events for desktop
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (selectedShape === null) return;
    const pos = getGridPosition(e.clientX, e.clientY - 40);
    if (pos) {
      setDragPosition(pos);
      setIsDragging(true);
    }
  }, [selectedShape, getGridPosition]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging || selectedShape === null) return;
    const pos = getGridPosition(e.clientX, e.clientY - 40);
    setDragPosition(pos);
  }, [isDragging, selectedShape, getGridPosition]);

  const handleMouseUp = useCallback(() => {
    if (!isDragging || selectedShape === null || !dragPosition) {
      setIsDragging(false);
      return;
    }

    const shape = gameState.shapes[selectedShape];
    if (shape) {
      const bounds = getShapeBounds(shape.cells);
      const adjustedPos: Position = {
        row: dragPosition.row - Math.floor((bounds.maxRow - bounds.minRow) / 2),
        col: dragPosition.col - Math.floor((bounds.maxCol - bounds.minCol) / 2),
      };

      const placed = onPlaceShape(selectedShape, adjustedPos);
      if (placed) {
        setSelectedShape(null);
      }
    }

    setIsDragging(false);
    setDragPosition(null);
  }, [isDragging, selectedShape, dragPosition, gameState.shapes, onPlaceShape]);

  // Also handle click to place
  const handleGridClick = useCallback((e: React.MouseEvent) => {
    if (selectedShape === null) return;
    const pos = getGridPosition(e.clientX, e.clientY);
    if (!pos) return;

    const shape = gameState.shapes[selectedShape];
    if (!shape) return;

    const bounds = getShapeBounds(shape.cells);
    const adjustedPos: Position = {
      row: pos.row - Math.floor((bounds.maxRow - bounds.minRow) / 2),
      col: pos.col - Math.floor((bounds.maxCol - bounds.minCol) / 2),
    };

    const placed = onPlaceShape(selectedShape, adjustedPos);
    if (placed) {
      setSelectedShape(null);
    }
  }, [selectedShape, gameState.shapes, onPlaceShape, getGridPosition]);

  const dragShape = selectedShape !== null ? gameState.shapes[selectedShape] : null;

  return (
    <motion.div
      ref={containerRef}
      className="flex flex-col h-full px-4 py-4 relative"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between mb-3">
        <motion.button
          onClick={onMenu}
          whileTap={{ scale: 0.9 }}
          className="w-9 h-9 rounded-full flex items-center justify-center text-sm"
          style={{
            background: 'rgba(255,255,255,0.05)',
            border: `1px solid ${theme.cellBorder}`,
            color: theme.textSecondary,
          }}
        >
          ✕
        </motion.button>

        <div className="text-center">
          <motion.p
            className="text-3xl font-light tabular-nums"
            key={gameState.score}
            initial={{ scale: 1.2 }}
            animate={{ scale: 1 }}
            style={{ color: theme.textPrimary }}
          >
            {gameState.score.toLocaleString()}
          </motion.p>
          {gameState.mode === 'level' && gameState.level && (
            <p className="text-[10px] uppercase tracking-wider" style={{ color: theme.textSecondary }}>
              Level {gameState.level}
            </p>
          )}
        </div>

        <div className="text-right">
          <p className="text-[10px] uppercase tracking-wider" style={{ color: theme.textSecondary }}>Best</p>
          <p className="text-sm font-light" style={{ color: theme.textSecondary }}>
            {gameState.highScore.toLocaleString()}
          </p>
        </div>
      </div>

      {/* Combo Indicator */}
      <AnimatePresence>
        {showCombo && gameState.combo > 1 && (
          <motion.div
            className="absolute top-16 left-1/2 -translate-x-1/2 z-40"
            initial={{ opacity: 0, y: 10, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.8 }}
          >
            <div
              className="px-4 py-2 rounded-full text-sm font-medium"
              style={{
                background: `${theme.accent}20`,
                border: `1px solid ${theme.accent}40`,
                color: theme.accent,
                boxShadow: `0 0 20px ${theme.accent}30`,
              }}
            >
              Combo x{gameState.combo} {lastScore > 0 && `+${lastScore}`}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Grid */}
      <div className="flex-1 flex items-center justify-center relative">
        <div
          ref={gridRef}
          className="w-full max-w-[min(90vw,400px)] relative"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onClick={handleGridClick}
        >
          <Grid
            grid={gameState.grid}
            gridColors={gameState.gridColors}
            theme={theme}
            clearedCells={clearedCells}
            dragShape={isDragging ? dragShape : null}
            dragPosition={isDragging ? dragPosition : null}
          />
          <ParticleEffect
            cells={clearedCells}
            theme={theme}
            gridSize={gridSize}
            gridRef={gridRef as React.RefObject<HTMLDivElement>}
          />
        </div>
      </div>

      {/* Shape Tray */}
      <div className="mt-auto">
        {!selectedShape && selectedShape !== 0 && (
          <p className="text-center text-xs mb-2" style={{ color: theme.textSecondary }}>
            Select a shape to place
          </p>
        )}
        {selectedShape !== null && (
          <p className="text-center text-xs mb-2" style={{ color: theme.accent }}>
            Tap on the grid to place
          </p>
        )}
        <ShapeTray
          shapes={gameState.shapes}
          theme={theme}
          selectedIndex={selectedShape}
          onSelect={(idx) => setSelectedShape(selectedShape === idx ? null : idx)}
        />
      </div>

      {/* Game Over Overlay */}
      <AnimatePresence>
        {gameState.isGameOver && (
          <GameOverScreen
            theme={theme}
            gameState={gameState}
            onRestart={onRestart}
            onMenu={onMenu}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
};
