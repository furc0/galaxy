import { useState, useCallback, useRef } from 'react';
import { GameState, Position, Shape } from './types';
import { themes } from './themes';
import {
  createInitialState,
  canPlaceShape,
  placeShape,
  findCompletedLines,
  clearLines,
  calculateScore,
  canAnyShapeBePlaced,
} from './gameLogic';
import { generateShapes } from './shapes';
import { getDifficultyForLevel } from './gameLogic';
import { unlockLevel, calculateStars, setLevelStars } from './levels';
import { playPlaceSound, playClearSound, playComboSound, playGameOverSound } from './sounds';

export function useGame() {
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [clearedCells, setClearedCells] = useState<Position[]>([]);
  const [showCombo, setShowCombo] = useState(false);
  const [lastScore, setLastScore] = useState(0);
  const comboTimeoutRef = useRef<ReturnType<typeof setTimeout>>();

  const currentTheme = gameState
    ? themes[Math.floor((gameState.totalLinesCleared || 0) / 3) % themes.length]
    : themes[0];

  const startFreeGame = useCallback(() => {
    const colors = themes[0].colors;
    setGameState(createInitialState(colors, 'free'));
  }, []);

  const startLevel = useCallback((levelId: number) => {
    const colors = themes[0].colors;
    setGameState(createInitialState(colors, 'level', levelId));
  }, []);

  const placeShapeAt = useCallback((shapeIndex: number, position: Position) => {
    if (!gameState || gameState.isGameOver) return false;

    const shape = gameState.shapes[shapeIndex];
    if (!shape) return false;

    if (!canPlaceShape(gameState.grid, shape, position)) return false;

    // Play placement sound
    playPlaceSound();

    // Place the shape
    const { newGrid, newColorGrid } = placeShape(
      gameState.grid,
      gameState.gridColors,
      shape,
      position
    );

    // Check for completed lines
    const { rows, cols } = findCompletedLines(newGrid);
    const totalLines = rows.length + cols.length;

    let finalGrid = newGrid;
    let finalColorGrid = newColorGrid;
    let newCombo = 0;
    let scoreGain = 0;
    let newLinesCleared = gameState.linesCleared;
    let newTotalLines = gameState.totalLinesCleared;

    if (totalLines > 0) {
      // Clear lines with animation
      const { newGrid: clearedGrid, newColorGrid: clearedColorGrid, cellsCleared } = clearLines(
        newGrid,
        newColorGrid,
        rows,
        cols
      );
      finalGrid = clearedGrid;
      finalColorGrid = clearedColorGrid;
      setClearedCells(cellsCleared);

      newCombo = gameState.combo + 1;
      scoreGain = calculateScore(totalLines, newCombo);
      newLinesCleared += totalLines;
      newTotalLines += totalLines;

      // Play sounds
      playClearSound(newCombo);
      if (newCombo > 1) {
        playComboSound(newCombo);
      }

      // Show combo indicator
      setShowCombo(true);
      if (comboTimeoutRef.current) clearTimeout(comboTimeoutRef.current);
      comboTimeoutRef.current = setTimeout(() => setShowCombo(false), 1500);

      // Clear animation after delay
      setTimeout(() => setClearedCells([]), 400);
    } else {
      newCombo = 0;
    }

    // Remove placed shape and generate new if needed
    const updatedShapes: (Shape | null)[] = gameState.shapes.map((s, i) => i === shapeIndex ? null : s);

    // If all shapes used, generate new set
    const allUsed = updatedShapes.every(s => s === null);
    let finalShapes: (Shape | null)[];
    if (allUsed) {
      const difficulty = gameState.mode === 'level' && gameState.level
        ? getDifficultyForLevel(gameState.level)
        : Math.min(Math.floor(newTotalLines / 3) + 1, 10);
      const themeIndex = Math.floor(newTotalLines / 3) % themes.length;
      const colors = themes[themeIndex].colors;
      finalShapes = generateShapes(3, colors, difficulty);
    } else {
      finalShapes = updatedShapes;
    }

    const newScore = gameState.score + scoreGain;
    setLastScore(scoreGain);

    // Check game over
    const isGameOver = !canAnyShapeBePlaced(finalGrid, finalShapes);

    // Update high score
    let highScore = gameState.highScore;
    if (newScore > highScore) {
      highScore = newScore;
      localStorage.setItem('prism_highscore', highScore.toString());
    }

    // Level completion check
    if (gameState.mode === 'level' && gameState.level && !isGameOver) {
      const stars = calculateStars(newScore, 0); // Will be calculated at end
      if (newLinesCleared >= 100) { // Level complete condition
        const levelStars = calculateStars(newScore, 1000);
        setLevelStars(gameState.level, levelStars);
        unlockLevel(gameState.level + 1);
      }
    }

    setGameState({
      ...gameState,
      grid: finalGrid,
      gridColors: finalColorGrid,
      score: newScore,
      highScore,
      combo: newCombo,
      maxCombo: Math.max(gameState.maxCombo, newCombo),
      shapes: finalShapes,
      isGameOver,
      linesCleared: newLinesCleared,
      totalLinesCleared: newTotalLines,
    });

    return true;
  }, [gameState]);

  const resetGame = useCallback(() => {
    setGameState(null);
    setClearedCells([]);
    setShowCombo(false);
    setLastScore(0);
  }, []);

  return {
    gameState,
    currentTheme,
    clearedCells,
    showCombo,
    lastScore,
    startFreeGame,
    startLevel,
    placeShapeAt,
    resetGame,
  };
}
