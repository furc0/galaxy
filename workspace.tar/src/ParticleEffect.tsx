import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Position, Theme } from './types';

interface Particle {
  id: number;
  x: number;
  y: number;
  color: string;
  size: number;
  angle: number;
  speed: number;
}

interface ParticleEffectProps {
  cells: Position[];
  theme: Theme;
  gridSize: number;
  gridRef: React.RefObject<HTMLDivElement>;
}

let particleId = 0;

export const ParticleEffect: React.FC<ParticleEffectProps> = ({ cells, theme, gridSize, gridRef }) => {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    if (cells.length === 0 || !gridRef.current) return;

    const rect = gridRef.current.getBoundingClientRect();
    const cellWidth = rect.width / gridSize;
    const cellHeight = rect.height / gridSize;

    const newParticles: Particle[] = [];
    cells.forEach(cell => {
      const cx = cell.col * cellWidth + cellWidth / 2;
      const cy = cell.row * cellHeight + cellHeight / 2;

      for (let i = 0; i < 3; i++) {
        particleId++;
        newParticles.push({
          id: particleId,
          x: cx,
          y: cy,
          color: theme.particleColors[Math.floor(Math.random() * theme.particleColors.length)],
          size: 3 + Math.random() * 5,
          angle: Math.random() * Math.PI * 2,
          speed: 20 + Math.random() * 40,
        });
      }
    });

    setParticles(newParticles);

    const timeout = setTimeout(() => {
      setParticles([]);
    }, 800);

    return () => clearTimeout(timeout);
  }, [cells, theme, gridSize, gridRef]);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl">
      <AnimatePresence>
        {particles.map(p => (
          <motion.div
            key={p.id}
            className="absolute rounded-full"
            initial={{
              x: p.x,
              y: p.y,
              scale: 1,
              opacity: 1,
            }}
            animate={{
              x: p.x + Math.cos(p.angle) * p.speed,
              y: p.y + Math.sin(p.angle) * p.speed,
              scale: 0,
              opacity: 0,
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            style={{
              width: p.size,
              height: p.size,
              background: p.color,
              boxShadow: `0 0 ${p.size * 2}px ${p.color}`,
            }}
          />
        ))}
      </AnimatePresence>
    </div>
  );
};
