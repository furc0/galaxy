import React from 'react';
import { motion } from 'framer-motion';
import { Theme } from './types';
import { levels, getUnlockedLevels, getLevelStars } from './levels';

interface LevelsScreenProps {
  theme: Theme;
  onSelectLevel: (id: number) => void;
  onBack: () => void;
}

export const LevelsScreen: React.FC<LevelsScreenProps> = ({ theme, onSelectLevel, onBack }) => {
  const unlockedLevel = getUnlockedLevels();

  return (
    <motion.div
      className="flex flex-col h-full px-6 py-8"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3 }}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <motion.button
          onClick={onBack}
          whileTap={{ scale: 0.9 }}
          className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{
            background: 'rgba(255,255,255,0.05)',
            border: `1px solid ${theme.cellBorder}`,
            color: theme.textPrimary,
          }}
        >
          ←
        </motion.button>
        <h2 className="text-xl font-light tracking-wider" style={{ color: theme.textPrimary }}>
          Levels
        </h2>
        <div className="w-10" />
      </div>

      {/* Level Grid */}
      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-3 gap-3">
          {levels.map((level, index) => {
            const isUnlocked = level.id <= unlockedLevel;
            const stars = getLevelStars(level.id);

            return (
              <motion.button
                key={level.id}
                className="relative rounded-xl p-3 flex flex-col items-center gap-1"
                onClick={() => isUnlocked && onSelectLevel(level.id)}
                whileTap={isUnlocked ? { scale: 0.95 } : {}}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                style={{
                  background: isUnlocked
                    ? `linear-gradient(135deg, ${theme.accent}15, ${theme.accent}05)`
                    : 'rgba(255,255,255,0.02)',
                  border: `1px solid ${isUnlocked ? theme.accent + '30' : theme.cellBorder}`,
                  opacity: isUnlocked ? 1 : 0.4,
                }}
              >
                <span
                  className="text-2xl font-light"
                  style={{ color: isUnlocked ? theme.textPrimary : theme.textSecondary }}
                >
                  {isUnlocked ? level.id : '🔒'}
                </span>
                <span
                  className="text-[10px] tracking-wider truncate w-full text-center"
                  style={{ color: theme.textSecondary }}
                >
                  {level.name}
                </span>
                {isUnlocked && (
                  <div className="flex gap-0.5 mt-1">
                    {[1, 2, 3].map(s => (
                      <div
                        key={s}
                        className="w-2 h-2 rounded-full"
                        style={{
                          background: s <= stars ? theme.accent : 'rgba(255,255,255,0.1)',
                          boxShadow: s <= stars ? `0 0 4px ${theme.accent}` : 'none',
                        }}
                      />
                    ))}
                  </div>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
};
